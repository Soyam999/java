import javax.swing.*;
import java.awt.*;
public class Gamepanel extends JPanel implements Runnable{
    Thread thread;
    int x=0,y=0;
    Gamepanel()
    {
        super();
        this.setPreferredSize(new Dimension(500,500));
        this.setBackground(Color.BLACK);
    }
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.setColor(Color.red);
        g.fillRect(x, y,100, 100);
    }
    public void startgame()
    {
        thread=new Thread(this);
        thread.start();
    }
    public void update()
    {

    }
    @Override
    public void run() 
    {
        double drawInterval=1000000000/60;
        double deltatime=0;
        long lastpassedtime=System.nanoTime();
        long currenttime=0;
        while (thread !=null)
        {
           currenttime=System.nanoTime();
           deltatime+=(currenttime-lastpassedtime)/drawInterval;
           lastpassedtime=currenttime;
           if(deltatime>=1)
           {
            x=x+5;
            repaint();
            deltatime--;
           }
        }
    }
}
